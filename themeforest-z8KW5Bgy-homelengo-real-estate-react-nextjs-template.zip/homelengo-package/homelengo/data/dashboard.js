export const messages = [
  {
    avatarSrc: "/images/avatar/avt-png9.png",
    name: "Themesflat",
    timeAgo: "3 days ago",
    message:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean scelerisque vulputate tincidunt. Maecenas lorem sapien",
  },
  {
    avatarSrc: "/images/avatar/avt-png10.png",
    name: "ThemeMu",
    timeAgo: "3 days ago",
    message:
      "Nullam lacinia lorem id sapien suscipit, vitae pellentesque metus maximus. Duis eu mollis dolor. Proin faucibus eu lectus a eleifend",
  },
  {
    avatarSrc: "/images/avatar/avt-png11.png",
    name: "Cameron Williamson",
    timeAgo: "3 days ago",
    message: "In consequat lacus augue, a vestibulum est aliquam non",
  },
  {
    avatarSrc: "/images/avatar/avt-png12.png",
    name: "Esther Howard",
    timeAgo: "3 days ago",
    message:
      "Cras congue in justo vel dapibus. Praesent euismod, lectus et aliquam pretium",
  },
];

export const reviews = [
  {
    avatarSrc: "/images/avatar/avt-png13.png",
    name: "Bessie Cooper",
    timeAgo: "3 days ago",
    message: "Maecenas eu lorem et urna accumsan vestibulum vel vitae magna.",
  },
  {
    avatarSrc: "/images/avatar/avt-png14.png",
    name: "Annette Black",
    timeAgo: "3 days ago",
    message:
      "Nullam rhoncus dolor arcu, et commodo tellus semper vitae. Aenean finibus tristique lectus, ac lobortis mauris venenatis ac.",
  },
  {
    avatarSrc: "/images/avatar/avt-png15.png",
    name: "Ralph Edwards",
    timeAgo: "3 days ago",
    message:
      "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus viverra semper convallis. Integer vestibulum tempus tincidunt.",
  },
  {
    avatarSrc: "/images/avatar/avt-png16.png",
    name: "Jerome Bell",
    timeAgo: "3 days ago",
    message:
      "Fusce sit amet purus eget quam eleifend hendrerit nec a erat. Sed turpis neque, iaculis blandit viverra ut, dapibus eget nisi.",
  },
  {
    avatarSrc: "/images/avatar/avt-png17.png",
    name: "Albert Flores",
    timeAgo: "3 days ago",
    message:
      "Donec bibendum nibh quis nisl luctus, at aliquet ipsum bibendum. Fusce at dui tincidunt nulla semper venenatis at et magna. Mauris turpis lorem, ultricies vel justo sed.",
  },
];
