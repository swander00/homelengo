export const sliderImages = [
  {
    src: "/images/slider/slider-2.jpg",
    alt: "images",
    width: 960,
    height: 730,
    className: "img-animation wow",
  },
  {
    src: "/images/slider/slider-2-1.jpg",
    alt: "images",
    width: 960,
    height: 730,
  },
  {
    src: "/images/slider/slider-2-3.jpg",
    alt: "images",
    width: 960,
    height: 730,
  },
];

export const sliderImages2 = [
  "/images/slider/slider-5.jpg",
  "/images/slider/slider-5-1.jpg",
  "/images/slider/slider-5-2.jpg",
  "/images/slider/slider-5-3.jpg",
];

export const sliderThumbnailImages = [
  "/images/slider/slider-pagi.jpg",
  "/images/slider/slider-pagi2.jpg",
  "/images/slider/slider-pagi3.jpg",
  "/images/slider/slider-pagi4.jpg",
];
