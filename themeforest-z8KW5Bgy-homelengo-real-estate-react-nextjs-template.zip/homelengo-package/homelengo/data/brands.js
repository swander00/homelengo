export const partners = [
  { src: "/images/partner/partner1.svg", width: 160, height: 80 },
  { src: "/images/partner/partner2.svg", width: 160, height: 80 },
  { src: "/images/partner/partner3.svg", width: 160, height: 80 },
  { src: "/images/partner/partner4.svg", width: 160, height: 80 },
  { src: "/images/partner/partner5.svg", width: 160, height: 80 },
  { src: "/images/partner/partner6.svg", width: 160, height: 80 },
  { src: "/images/partner/partner1.svg", width: 160, height: 80 },
];
