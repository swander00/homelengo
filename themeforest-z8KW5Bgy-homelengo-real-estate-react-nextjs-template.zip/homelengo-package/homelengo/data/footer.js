export const footerSections = [
  {
    heading: "Categories",
    links: [
      { href: "/pricing", label: "Pricing Plans" },
      { href: "/our-service", label: "Our Services" },
      { href: "/about-us", label: "About Us" },
      { href: "/contact", label: "Contact Us" },
    ],
  },
  {
    heading: "Our Company",
    links: [
      { href: "/topmap-list", label: "Property For Sale" },
      { href: "/topmap-grid", label: "Property For Rent" },
      { href: "/topmap-grid", label: "Property For Buy" },
      { href: "/topmap-grid", label: "Our Agents" },
    ],
  },
];
