import FilterTab from "@/components/common/FilterTab";
import FlatFilter2 from "@/components/common/FlatFilter2";
import React from "react";

export default function Filter() {
  return (
    <div className="flat-control-search abs">
      <div className="container">
        <FilterTab />
      </div>
    </div>
  );
}
